This is an Ascii implimentation of Trie and LZW

**IMPORTANT: This implementation does not support unicode characters only ascii characters ranging from 0-127 is gauranteed; characters past 127 are platform dependent and thus some unicode characters may or may not be part of the initial LZW table **
